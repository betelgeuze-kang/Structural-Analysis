External validation submission bundle
Generated: 2026-03-30T15:06:27.956197+00:00
Bundle variant: external_validation_submission_20260330T150627Z

Contents
- external_validation_onepage.{json,md,html,pdf}
- validation and release reports
- signed release registry + public key + detached signature
- selected solver/parser/committee artifacts for external review

Notes
- This bundle supersedes previous bundles of the same variant.
- MIDAS parser contract records element_rows_skipped=0.
- NDTHA residual gate records hard-threshold residual trace status.
- release_registry.json is signed with Ed25519.
